class TrueClass
  def try_dup
    self
  end
end

class FalseClass
  def try_dup
    self
  end
end
